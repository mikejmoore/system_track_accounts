
class UsersRole < ActiveRecord::Base
end

class TestConstants
  MAIN_ACCOUNT = {
    name: "Primary Account",
    code: "primary"
  }
  
  SUPER_USER = {
    email: "super.user@systrack.com",
    first_name: "Some",
    last_name:  "Person",
    password: "secret123"
    
  }
end
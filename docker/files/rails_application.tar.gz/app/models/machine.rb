class Machine < ActiveRecord::Base
  belongs_to :account
end


class TestUser < User
  attr_accessor :plain_password
end

class SshKey < ActiveRecord::Base
  belongs_to :user
  
end
